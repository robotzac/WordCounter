import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

//Author Name: Zachery Craft
//Date: 6/26/2021
//Program Name: Craft_module7_word_occurrence
//Purpose: To create a program that reads a file and outputs statistics about that file.
 
/**
 * Begin program
 * @author zacherycraft
 *
 */
	
public class WordCounter {
	
	public static String printWords(List words, List count) {
		
		String result= "test";
		for(int i = words.size()-20; i< words.size(); i++) {
		String result1 = (words.get(i) + " was found " + count.get(i) + " times");
		result += result1 + "\n";	
	}
		
		return result.toString();
		}
	

	public static void main(String[] args) throws IOException  {


		GUI hello = new GUI();
		
		/**
		 * Create input stream and scanner
		 */
		FileInputStream finput = new FileInputStream("text.txt");
		Scanner fileInput = new Scanner(finput);

		
		/*
		 * Create arraylists
		 */
		ArrayList<String> words = new ArrayList<String>();
		ArrayList<Integer> count = new ArrayList<Integer>();
		
		/*
		 * Go through file, locate words
		 */
		
		while(fileInput.hasNext()) {
			String nextWord = fileInput.next();
			
			/*
			 * Check if word is in arraylist already
			 */
			
			if(words.contains(nextWord)) {
				int index = words.indexOf(nextWord);
				count.set(index,count.get(index) + 1);
			}
			else {
				words.add(nextWord);
				count.add(1);
			}
		}
		
		/*
		 * Sort and print Results
		 */
		Collections.sort(count);
		
		System.out.println(printWords(words, count));
		
		fileInput.close();
		finput.close();

}
		
}
