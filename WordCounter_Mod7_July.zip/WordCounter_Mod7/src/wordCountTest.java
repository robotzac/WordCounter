
//Author Name: Zachery Craft
//Date: 7/3/2021
//Program Name: Craft_module7_word_occurrence
//Purpose: To add a JUnit class to WordCounter program


import static org.junit.jupiter.api.Assertions.*;

import java.awt.List;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class wordCountTest {
	/**
	 * The wordCountTest class establishes the JUnit tests which test input validation.
	 */
	static ArrayList<String> words1 = new ArrayList<String>();
	static ArrayList<Integer> count1 = new ArrayList<Integer>();
	

	@Test
	public void test() {
		WordCounter test = new WordCounter();
		String expectedResult = null;
		String output = test.printWords(words1, count1);
		assertEquals(expectedResult, output);
	}
}
