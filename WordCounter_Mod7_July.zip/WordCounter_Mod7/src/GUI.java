import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * GUI Class
 * @author zacherycraft
 *This class defines the methods and attributes for GUI objects
 */


public class GUI implements ActionListener{
	
	static List words;
	static List count;
	
	/**
	 * GUI class contains two variables
	 * @param args
	 */

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(400,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		JPanel panel = new JPanel();
		frame.add(panel);
		
		panel.setLayout(null);
		
		JLabel userlabel = new JLabel("Thank you for using the word counting program. Click below to see results.");
		userlabel.setBounds(1, 4, 4, 1);
		panel.add(userlabel);
		
		frame.setVisible(true);
		
		JButton button = new JButton("Click here to see results");
				button.setBounds(10, 200, 200, 25);
				button.addActionListener(null);
				panel.add(button);
		
		
	}


	public static void actionPerformed(ActionEvent e, List words, List count) {
		for(int i = words.size()-20 ; i< words.size(); i++) {
			System.out.println(words.get(i) + " was found " + count.get(i) + " times");
		}	
	}
	/**
	 * The actionPerformed method requires three arguments and creates the results text
	 */

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	}

